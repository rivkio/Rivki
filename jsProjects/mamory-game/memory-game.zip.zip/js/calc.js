const add = (x, y) => x + y;
const substract = (x, y) => x - y;
const mult = (x, y) => x * y;
const div = (x, y) => x / y;

export const ops = {
    add,
    substract,
    mult,
    div
}