// function showDateTimeIn(locale = 'he-IL', timeZone = 'Asia/Jerusalem') {
//     const date = new Date();
//     const dateString = date.toLocaleDateString(locale, {
//         timeZone: timeZone,
//     })
//     const timeString = date.toLocaleTimeString(locale, {
//         timeZone: timeZone,
//     })
//     console.log(dateString);
//     console.log(timeString);
// }
// showDateTimeIn(locale = 'fr-FR', timeZone = 'Europe/Paris');

